import React, { useState } from 'react';
import { 
  Calculator, 
  Search, 
  Calendar, 
  FileText, 
  GitFork, 
  Copy, 
  Check, 
  ArrowRight, 
  Sparkles, 
  HelpCircle,
  Lightbulb,
  Layers,
  ChevronRight
} from 'lucide-react';
import { 
  FORMULA_CATEGORIES_META, 
  CATEGORY_FUNCTIONS, 
  CategoryId, 
  CategoryFunctionItem 
} from '../data/formulaCategories';
import { InteractiveSpreadsheet } from './InteractiveSpreadsheet';
import { copyFormulaToClipboard } from '../utils/clipboard';

interface FormulaCategoriesSectionProps {
  onSendToGenerator: (prompt: string) => void;
  onSendToExplainer: (formula: string) => void;
}

const CATEGORY_ICONS: Record<CategoryId, React.ComponentType<{ className?: string }>> = {
  calculs: Calculator,
  recherche: Search,
  dates: Calendar,
  texte: FileText,
  conditions: GitFork,
};

export const FormulaCategoriesSection: React.FC<FormulaCategoriesSectionProps> = ({
  onSendToGenerator,
  onSendToExplainer,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('calculs');
  
  // Functions for current category
  const categoryFunctions = CATEGORY_FUNCTIONS.filter(f => f.category === selectedCategory);
  
  // Currently active function within category
  const [activeFunctionId, setActiveFunctionId] = useState<string>(categoryFunctions[0].id);
  const [copied, setCopied] = useState(false);

  // Active function item
  const activeFunction: CategoryFunctionItem = 
    categoryFunctions.find(f => f.id === activeFunctionId) || categoryFunctions[0];

  const handleSelectCategory = (catId: CategoryId) => {
    setSelectedCategory(catId);
    const firstFn = CATEGORY_FUNCTIONS.find(f => f.category === catId);
    if (firstFn) {
      setActiveFunctionId(firstFn.id);
    }
  };

  const handleCopyFormula = async () => {
    const ok = await copyFormulaToClipboard(activeFunction.formulaExample);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const activeMeta = FORMULA_CATEGORIES_META.find(m => m.id === selectedCategory)!;

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 text-emerald-700 text-xs font-semibold tracking-wide uppercase mb-1">
            <Layers className="w-4 h-4" />
            <span>Guide Officiel par Thématique</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Catégories de formules Excel
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Explorez les 5 grandes familles de fonctions indispensables. Sélectionnez une catégorie pour découvrir ses fonctions, leur explication simple et tester un exemple concret.
          </p>
        </div>

        {/* 5 Category Buttons (Mobile-friendly grid / cards) */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {FORMULA_CATEGORIES_META.map((cat) => {
            const Icon = CATEGORY_ICONS[cat.id];
            const isSelected = selectedCategory === cat.id;

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleSelectCategory(cat.id)}
                className={`p-3 rounded-xl border text-left transition cursor-pointer active:scale-95 flex flex-col justify-between min-h-[72px] sm:min-h-[82px] ${
                  isSelected
                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-sm ring-2 ring-emerald-500/20'
                    : 'bg-slate-50 hover:bg-emerald-50/60 text-slate-800 border-slate-200 hover:border-emerald-300'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-emerald-800 text-white' : 'bg-white text-emerald-700 shadow-2xs'}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${isSelected ? 'bg-emerald-800/90 text-emerald-100' : 'bg-slate-200/80 text-slate-600'}`}>
                    {cat.badge}
                  </span>
                </div>
                <div className="mt-1.5">
                  <span className="font-bold text-xs sm:text-sm block leading-tight">
                    {cat.title}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Function Selection Chips Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
              Fonctions disponibles dans {activeMeta.title} :
            </span>
          </div>
          <span className="text-xs text-slate-500">
            {activeMeta.description}
          </span>
        </div>

        {/* Function Chips */}
        <div className="flex flex-wrap gap-2">
          {categoryFunctions.map((fn) => {
            const isSelected = activeFunction.id === fn.id;
            return (
              <button
                key={fn.id}
                type="button"
                onClick={() => setActiveFunctionId(fn.id)}
                className={`px-3.5 py-2 rounded-lg border font-mono text-xs font-bold transition cursor-pointer min-h-[42px] flex items-center gap-2 active:scale-95 ${
                  isSelected
                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs ring-2 ring-emerald-500/20'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-emerald-50 hover:text-emerald-900 hover:border-emerald-300'
                }`}
              >
                <span>{fn.name}</span>
                <span className={`text-[10px] font-sans font-normal opacity-75 ${isSelected ? 'text-emerald-200' : 'text-slate-400'}`}>
                  ({fn.englishName})
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Function Detailed Card & Example */}
      <div className="space-y-6">
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          {/* Header of the Function */}
          <div className="p-5 bg-gradient-to-r from-emerald-800 to-emerald-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono text-lg sm:text-xl font-bold bg-emerald-700/80 px-2.5 py-0.5 rounded border border-emerald-600/50">
                  {activeFunction.name}
                </span>
                <span className="text-xs text-emerald-200 font-sans">
                  Équivalent anglais : <strong>{activeFunction.englishName}</strong>
                </span>
              </div>
              <p className="text-sm text-emerald-100 font-medium">
                {activeFunction.role}
              </p>
            </div>

            {/* Top Action Buttons */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleCopyFormula}
                className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 text-xs font-bold bg-white text-emerald-900 hover:bg-emerald-50 rounded-lg transition shadow-xs cursor-pointer active:scale-95"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? '✓ Formule copiée !' : 'Copier la formule'}</span>
              </button>

              <button
                type="button"
                onClick={() => onSendToGenerator(activeFunction.role)}
                className="inline-flex items-center gap-1 min-h-[40px] px-3.5 py-2 text-xs font-medium bg-emerald-800 hover:bg-emerald-700 text-white border border-emerald-600/40 rounded-lg transition cursor-pointer"
                title="Générer avec l'IA"
              >
                <span>Adapter</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Formula Display Bar */}
          <div className="p-4 sm:p-5 bg-slate-900 text-emerald-400 font-mono text-sm sm:text-base overflow-x-auto border-b border-slate-200 flex items-center justify-between gap-3">
            <code>{activeFunction.formulaExample}</code>
            <span className="text-[11px] font-sans text-slate-400 shrink-0 hidden sm:inline">
              Syntaxe française (séparateur point-virgule ;)
            </span>
          </div>

          {/* Explanation & Details Body */}
          <div className="p-5 sm:p-6 space-y-4">
            {/* Simple explanation */}
            <div>
              <h2 className="text-xs uppercase font-semibold text-slate-500 tracking-wider mb-1.5">
                Explication simple pour débutants :
              </h2>
              <p className="text-sm text-slate-800 leading-relaxed font-medium">
                {activeFunction.simpleExplanation}
              </p>
            </div>

            {/* Syntax and detail */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-700">Syntaxe officielle :</span>
                <code className="font-mono font-bold text-emerald-900 bg-emerald-100/70 px-2 py-0.5 rounded">
                  {activeFunction.syntax}
                </code>
              </div>
              <p className="text-slate-600 text-xs">
                {activeFunction.syntaxDetail}
              </p>
            </div>

            {/* Pro Tip */}
            <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2.5">
              <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-950 font-semibold block mb-0.5">Astuce pratique :</strong>
                <span>{activeFunction.proTip}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Spreadsheet Live Preview */}
        <InteractiveSpreadsheet
          data={activeFunction.sampleData}
          formula={activeFunction.formulaExample}
          title={`Exemple interactif : ${activeFunction.name}`}
          subtitle="Modifiez les cellules blanches pour tester le calcul en direct"
        />
      </div>
    </div>
  );
};
